package com.student.controller;

import com.student.dao.StudentDAO;
import com.student.model.Student;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.WebServlet;
import java.io.IOException;

@WebServlet("/students")
public class StudentController extends HttpServlet {

    private final StudentDAO dao = new StudentDAO();
    private static final int PAGE_SIZE = 10;

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = req.getParameter("action");
        if (action == null) action = "list";

        switch (action) {
            case "add" -> showForm(req, resp, new Student());
            case "edit" -> {
                int id = Integer.parseInt(req.getParameter("id"));
                Student s = dao.getStudentById(id);
                showForm(req, resp, s);
            }
            case "delete" -> {
                dao.deleteStudent(Integer.parseInt(req.getParameter("id")));
                resp.sendRedirect("students?message=Xóa thành công!");
            }
            default -> listStudents(req, resp);
        }
    }

    private void listStudents(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        int page = 1;
        String p = req.getParameter("page");
        if (p != null && !p.isEmpty()) page = Integer.parseInt(p);

        var students = dao.getStudentsPaginated(page, PAGE_SIZE);
        int total = dao.getTotalStudents();
        int totalPages = (int) Math.ceil((double) total / PAGE_SIZE);

        req.setAttribute("listStudent", students);
        req.setAttribute("currentPage", page);
        req.setAttribute("totalPages", totalPages);
        req.setAttribute("totalStudents", total);

        req.getRequestDispatcher("/views/student-list.jsp").forward(req, resp);
    }

    private void showForm(HttpServletRequest req, HttpServletResponse resp, Student s) throws ServletException, IOException {
        req.setAttribute("student", s);
        req.getRequestDispatcher("/views/student-form.jsp").forward(req, resp);
    }

    // ==================== VALIDATE ====================
    private String validate(Student s) {
        StringBuilder err = new StringBuilder();
        if (s.getStudentCode() == null || !s.getStudentCode().matches("^[A-Z0-9]{8,20}$"))
            err.append("Mã sinh viên phải là chữ hoa + số, 8-20 ký tự.<br>");
        if (s.getFullName() == null || s.getFullName().trim().length() < 5)
            err.append("Họ tên phải từ 5 ký tự trở lên.<br>");
        if (s.getEmail() == null || !s.getEmail().matches("^[\\w.-]+@[\\w.-]+\\.[a-zA-Z]{2,}$"))
            err.append("Email không hợp lệ.<br>");
        if (s.getMajor() == null || s.getMajor().isEmpty())
            err.append("Vui lòng chọn chuyên ngành.<br>");
        return err.toString();
    }

    // ==================== INSERT ====================
    private void insertStudent(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Student s = new Student();
        s.setStudentCode(req.getParameter("studentCode").trim());
        s.setFullName(req.getParameter("fullName").trim());
        s.setEmail(req.getParameter("email").trim());
        s.setMajor(req.getParameter("major"));

        String err = validate(s);
        if (!err.isEmpty()) { req.setAttribute("errorMsg", err); showForm(req, resp, s); return; }

        if (dao.isStudentCodeExists(s.getStudentCode())) { req.setAttribute("errorMsg", "Mã sinh viên đã tồn tại!"); showForm(req, resp, s); return; }
        if (dao.isEmailExists(s.getEmail())) { req.setAttribute("errorMsg", "Email đã được sử dụng!"); showForm(req, resp, s); return; }

        if (dao.addStudent(s)) {
            resp.sendRedirect("students?message=Thêm thành công!");
        } else {
            req.setAttribute("errorMsg", "Lỗi hệ thống khi thêm!");
            showForm(req, resp, s);
        }
    }

    // ==================== UPDATE ====================
    private void updateStudent(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Student s = new Student();
        s.setId(Integer.parseInt(req.getParameter("id")));
        s.setStudentCode(req.getParameter("studentCode").trim());
        s.setFullName(req.getParameter("fullName").trim());
        s.setEmail(req.getParameter("email").trim());
        s.setMajor(req.getParameter("major"));

        String err = validate(s);
        if (!err.isEmpty()) { req.setAttribute("errorMsg", err); showForm(req, resp, s); return; }

        if (dao.isStudentCodeExists(s.getStudentCode(), s.getId())) { req.setAttribute("errorMsg", "Mã sinh viên đã tồn tại!"); showForm(req, resp, s); return; }
        if (dao.isEmailExists(s.getEmail(), s.getId())) { req.setAttribute("errorMsg", "Email đã được sử dụng!"); showForm(req, resp, s); return; }

        if (dao.updateStudent(s)) {
            resp.sendRedirect("students?message=Cập nhật thành công!");
        } else {
            req.setAttribute("errorMsg", "Lỗi hệ thống khi cập nhật!");
            showForm(req, resp, s);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = req.getParameter("action");
        if ("insert".equals(action)) insertStudent(req, resp);
        else if ("update".equals(action)) updateStudent(req, resp);
    }
}